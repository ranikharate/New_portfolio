i=1
while i<=100:
  print(i)
  i+=1
  # print no 1 to 100
